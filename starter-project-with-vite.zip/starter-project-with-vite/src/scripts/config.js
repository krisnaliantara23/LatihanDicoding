const CONFIG = {
  BASE_URL: 'https://api.themoviedb.org/3',
  API_KEY: 'd9439aa546664d778bab2395ca525287'
};

export default CONFIG;
