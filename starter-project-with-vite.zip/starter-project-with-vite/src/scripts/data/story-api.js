const StoryApi = {
  async submitData(data) {
    const response = await fetch('https://your-story-api.com/data', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (!response.ok) throw new Error('Gagal kirim data');
    return response.json();
  },

  async getAllData() {
    const response = await fetch('https://your-story-api.com/data'); 
    if (!response.ok) throw new Error('Gagal ambil data');
    return response.json(); 
  },
};

export default StoryApi;
