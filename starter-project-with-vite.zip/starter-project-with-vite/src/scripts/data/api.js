import CONFIG from '../config';

const ENDPOINTS = {
  ENDPOINT: `${CONFIG.BASE_URL}/movie/popular?api_key=${CONFIG.API_KEY}`,
};

export async function getData() {
  const fetchResponse = await fetch(ENDPOINTS.ENDPOINT);
  return await fetchResponse.json();
}
export async function getMovieDetails(id) {
  const fetchResponse = await fetch(`${CONFIG.BASE_URL}/movie/${id}?api_key=${CONFIG.API_KEY}`);
  return await fetchResponse.json();
}
export async function getMovieReviews(id) {
  const fetchResponse = await fetch(`${CONFIG.BASE_URL}/movie/${id}/reviews?api_key=${CONFIG.API_KEY}`);
  return await fetchResponse.json();
}
export async function getMovieVideos(id) {
  const fetchResponse = await fetch(`${CONFIG.BASE_URL}/movie/${id}/videos?api_key=${CONFIG.API_KEY}`);
  return await fetchResponse.json();
}
export async function getMovieRecommendations(id) {
  const fetchResponse = await fetch(`${CONFIG.BASE_URL}/movie/${id}/recommendations?api_key=${CONFIG.API_KEY}`);
  return await fetchResponse.json();
}