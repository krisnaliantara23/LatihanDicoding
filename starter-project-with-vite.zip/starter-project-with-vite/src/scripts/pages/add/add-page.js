import AddPresenter from '../../presenter/add-presenter';

export default class AddPage {
  constructor() {
    this.presenter = new AddPresenter();
  }

  async render() {
    return `
      <section class="container">
        <h1>Tambah Data Baru</h1>
        <form id="add-form">
          <label for="title">Judul:</label>
          <input type="text" id="title" name="title" required />

          <label for="description">Deskripsi:</label>
          <textarea id="description" name="description" required></textarea>

          <label for="image">Gambar (kamera):</label>
          <video id="video" width="300" autoplay></video>
          <button type="button" id="capture">Ambil Gambar</button>
          <canvas id="canvas" width="300" height="200" style="display:none;"></canvas>

          <label for="coordinates">Koordinat:</label>
          <input type="text" id="coordinates" name="coordinates" readonly />
          <div id="map" style="height: 300px; margin-top: 10px;"></div>

          <button type="submit">Simpan</button>
        </form>
      </section>
    `;
  }

  async afterRender() {
    this.presenter.init();
  }
}
