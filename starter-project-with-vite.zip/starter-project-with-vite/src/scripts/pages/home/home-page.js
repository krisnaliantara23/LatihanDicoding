import HomePresenter from '../../presenter/home-presenter.js';

export default class HomePage {
  constructor() {
    this.presenter = new HomePresenter();
  }

  async render() {
    return `
      <section class="container">
        <h1>Home Page</h1>
        <div id="movies-list"></div>
        <div id="map" style="height: 400px;"></div>
      </section>
    `;
  }

  async afterRender() {
    this.presenter.init();
  }
}
