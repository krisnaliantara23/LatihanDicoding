import { getData } from '../data/api.js';

export default class HomePresenter {
  async init() {
    try {
      const result = await getData();
      const data = result.results;
      this.renderList(data);
      this.renderMap();
    } catch (error) {
      console.error('Error fetching movie data:', error);
    }
  }

  renderList(data) {
    const container = document.getElementById('movies-list');
    container.innerHTML = '';

    data.forEach(item => {
      const div = document.createElement('div');
      div.classList.add('movie-item');
      div.innerHTML = `
        <img src="https://image.tmdb.org/t/p/w500${item.poster_path}" alt="${item.title}" />
        <h3>${item.title}</h3>
        <p>${item.overview}</p>
      `;
      container.appendChild(div);
    });
  }

  renderMap() {
    const map = L.map('map').setView([-6.2, 106.8], 10);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
    }).addTo(map);
  }
}
