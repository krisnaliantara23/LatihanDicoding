import StoryApi from '../data/story-api';

export default class AddPresenter {
  init() {
    this.initCamera();
    this.initMap();
    this.initForm();
  }

  async initCamera() {
    const video = document.getElementById('video');
    const canvas = document.getElementById('canvas');
    const captureBtn = document.getElementById('capture');
    const context = canvas.getContext('2d');

    // Periksa dukungan browser
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      alert('Perangkat Anda tidak mendukung kamera.');
      return;
    }

    try {
      // Minta akses ke kamera
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      video.srcObject = stream;
      video.play();

      captureBtn.addEventListener('click', () => {
        // Ambil gambar dari video ke canvas
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        canvas.style.display = 'block';

        // Stop semua track kamera setelah capture
        stream.getTracks().forEach(track => track.stop());
      });

    } catch (error) {
      alert('Gagal mengakses kamera. Pastikan Anda sudah memberi izin!');
      console.error('Camera access error:', error);
    }
  }

  initMap() {
    const coordInput = document.getElementById('coordinates');
    const map = L.map('map').setView([-6.2, 106.8], 10);

    // Tambahkan tile layer dari OpenStreetMap
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
    }).addTo(map);

    let marker;

    // Tambah marker ketika map diklik
    map.on('click', (e) => {
      const { lat, lng } = e.latlng;
      coordInput.value = `${lat}, ${lng}`;
      if (marker) map.removeLayer(marker);
      marker = L.marker([lat, lng]).addTo(map).bindPopup('Lokasi dipilih').openPopup();
    });
  }

  initForm() {
  const form = document.getElementById('add-form');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = document.getElementById('title').value;
    const description = document.getElementById('description').value;
    const coordinates = document.getElementById('coordinates').value;
    const canvas = document.getElementById('canvas');
    const image = canvas.toDataURL('image/png');

    const payload = { title, description, coordinates, image };

    try {
      await StoryApi.submitData(payload);
      alert('Data berhasil disimpan!');
      // Navigasi ke halaman home agar HomePage render ulang data terbaru
      window.location.hash = '#/';
    } catch (err) {
      alert('Gagal menyimpan data!');
      console.error(err);
    }
  });
}
  async submitData(payload) {
    try {
      const response = await StoryApi.submitData(payload);
      return response;
    } catch (error) {
      console.error('Error submitting data:', error);
      throw error;
    }
  }
}
