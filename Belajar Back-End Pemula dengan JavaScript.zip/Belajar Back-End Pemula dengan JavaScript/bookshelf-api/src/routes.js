const { addBookHandler, getAllBooksHandler } = require('./handlers');

const routes = (req, res) => {
  const { method, url } = req;

  // POST /books
  if (method === 'POST' && url === '/books') {
    return addBookHandler(req, res);
  }

  // GET /books
  if (method === 'GET' && url === '/books') {
    return getAllBooksHandler(req, res);
  }

  // Route tidak ditemukan
  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({
    status: 'fail',
    message: 'Halaman tidak ditemukan',
  }));
};

module.exports = routes;
