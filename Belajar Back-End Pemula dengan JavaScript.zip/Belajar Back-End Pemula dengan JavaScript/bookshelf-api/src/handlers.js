const { nanoid } = require('nanoid');
const books = require('./books');

// Handler untuk menambahkan buku
const addBookHandler = (req, res) => {
  let body = '';

  req.on('data', (chunk) => {
    body += chunk;
  });

  req.on('end', () => {
    try {
      const {
        name, year, author, summary,
        publisher, pageCount, readPage, reading,
      } = JSON.parse(body);

      // Validasi: nama wajib ada
      if (!name) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          status: 'fail',
          message: 'Gagal menambahkan buku. Mohon isi nama buku',
        }));
        return;
      }

      // Validasi: readPage tidak boleh lebih besar dari pageCount
      if (readPage > pageCount) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          status: 'fail',
          message: 'Gagal menambahkan buku. readPage tidak boleh lebih besar dari pageCount',
        }));
        return;
      }

      const id = nanoid(16);
      const insertedAt = new Date().toISOString();
      const updatedAt = insertedAt;
      const finished = pageCount === readPage;

      const newBook = {
        id, name, year, author, summary,
        publisher, pageCount, readPage,
        finished, reading, insertedAt, updatedAt,
      };

      books.push(newBook);

      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        status: 'success',
        message: 'Buku berhasil ditambahkan',
        data: {
          bookId: id,
        },
      }));
    } catch (error) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        status: 'error',
        message: 'Terjadi kesalahan pada server',
      }));
    }
  });
};

// Handler untuk mendapatkan semua buku
const getAllBooksHandler = (req, res) => {
  const bookList = books.map((book) => ({
    id: book.id,
    name: book.name,
    publisher: book.publisher,
  }));

  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({
    status: 'success',
    data: {
      books: bookList,
    },
  }));
};

module.exports = {
  addBookHandler,
  getAllBooksHandler,
};
