# Asesmen menulis komentar di JavaScript

## Instruksi pengerjaan `01-writing-comments`
Kerjakan tugas berikut untuk menyelesaikan _task_ `01-writing-comments`:
1. Buka berkas `index.js` dan tuliskan "username" akun Dicoding Anda dalam bentuk **komentar satu baris**.
2. Buka berkas `index.js` dan tuliskan teks di bawah ini dalam bentuk **komentar banyak baris**.

```text
Goal tahun ini:
1. Belajar JavaScript.
2. Menjadi Front-End atau Back-End Developer.
```

## Cara mengetahui username Dicoding
1. Buka halaman pengaturan akun Dicoding dengan klik url [https://www.dicoding.com/settings/profile](https://www.dicoding.com/settings/profile).
2. Jika belum login, silakan login dengan akun Dicoding yang Anda miliki.
4. Anda bisa lihat pada bagian kolom Username dan menyalinnya.
