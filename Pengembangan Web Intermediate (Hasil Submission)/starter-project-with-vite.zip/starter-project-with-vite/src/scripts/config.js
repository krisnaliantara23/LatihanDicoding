const CONFIG = {
  BASE_URL: 'https://www.themoviedb.org/movie',
  API_KEY: 'd9439aa546664d778bab2395ca525287',
  BASE_IMAGE_URL: 'https://image.tmdb.org/t/p/',
};

export default CONFIG;
